clear all;
close all;
clc;

fprintf('========================================\n');
fprintf('UAV-Assisted 5G NTN Simulation\n');
fprintf('========================================\n\n');

%% Configuration
config.carrierFrequency = 3.5e9;
config.bandwidth = 100e6;
config.gNB.position = [0, 0, 30];
config.gNB.txPower = 46;
config.gNB.antennaGain = 18;
config.gNB.antennaHeight = 30;
config.UAV.altitude = 100;
config.UAV.speed = 10;
config.UAV.orbitRadius = 200;
config.UAV.txPower = 30;
config.UAV.rxGain = 5;
config.UAV.txGain = 5;
config.UE.numUsers = 10;
config.UE.areaRadius = 500;
config.UE.antennaHeight = 1.5;
config.UE.rxGain = 0;
config.UE.noiseFigure = 9;
config.channel.environmentType = 'rural';
config.channel.LoS_probability = 0.9;
config.simTime = 60;
config.timeStep = 0.1;
config.metrics.SNR_threshold = -5;

fprintf('Configuration complete.\n\n');

%% Generate UE Positions
fprintf('Generating UE positions...\n');
r = config.UE.areaRadius * sqrt(rand(config.UE.numUsers, 1));
theta = 2 * pi * rand(config.UE.numUsers, 1);
ue_x = r .* cos(theta);
ue_y = r .* sin(theta);
ue_z = config.UE.antennaHeight * ones(config.UE.numUsers, 1);
fprintf('UE positions generated.\n\n');

%% Generate UAV Trajectory
fprintf('Generating UAV trajectory...\n');
time = 0:config.timeStep:config.simTime;
omega = config.UAV.speed / config.UAV.orbitRadius;
uav_x = config.UAV.orbitRadius * cos(omega * time);
uav_y = config.UAV.orbitRadius * sin(omega * time);
uav_z = config.UAV.altitude * ones(size(time));
fprintf('UAV trajectory generated.\n\n');

%% Baseline Scenario Simulation
fprintf('Running BASELINE scenario (no UAV)...\n');
baseline_SNR = zeros(config.UE.numUsers, length(time));
baseline_coverage = zeros(1, length(time));

for t = 1:length(time)
    for u = 1:config.UE.numUsers
        dist = sqrt((ue_x(u) - config.gNB.position(1))^2 + ...
                    (ue_y(u) - config.gNB.position(2))^2 + ...
                    (ue_z(u) - config.gNB.position(3))^2);
        
        PL = calculate_terrestrial_pathloss(dist, config);
        SNR = calculate_SNR(config.gNB.txPower, config.gNB.antennaGain, ...
                           config.UE.rxGain, PL, config.UE.noiseFigure, config.bandwidth);
        baseline_SNR(u, t) = SNR;
    end
    baseline_coverage(t) = 100 * sum(baseline_SNR(:, t) > config.metrics.SNR_threshold) / config.UE.numUsers;
end

baseline_avg_SNR = mean(baseline_SNR, 1);
fprintf('Baseline: Avg SNR = %.2f dB, Avg Coverage = %.1f%%\n\n', ...
        mean(baseline_avg_SNR), mean(baseline_coverage));

%% Proposed Scenario Simulation
fprintf('Running PROPOSED scenario (with UAV relay)...\n');
proposed_SNR = zeros(config.UE.numUsers, length(time));
proposed_coverage = zeros(1, length(time));

for t = 1:length(time)
    for u = 1:config.UE.numUsers
        dist = sqrt((ue_x(u) - uav_x(t))^2 + ...
                    (ue_y(u) - uav_y(t))^2 + ...
                    (ue_z(u) - uav_z(t))^2);
        
        PL = calculate_A2G_pathloss(dist, config);
        SNR = calculate_SNR(config.UAV.txPower, config.UAV.txGain, ...
                           config.UE.rxGain, PL, config.UE.noiseFigure, config.bandwidth);
        proposed_SNR(u, t) = SNR;
    end
    proposed_coverage(t) = 100 * sum(proposed_SNR(:, t) > config.metrics.SNR_threshold) / config.UE.numUsers;
end

proposed_avg_SNR = mean(proposed_SNR, 1);
fprintf('Proposed: Avg SNR = %.2f dB, Avg Coverage = %.1f%%\n\n', ...
        mean(proposed_avg_SNR), mean(proposed_coverage));

%% Results
improvement_SNR = mean(proposed_avg_SNR) - mean(baseline_avg_SNR);
improvement_coverage = mean(proposed_coverage) - mean(baseline_coverage);
fprintf('========================================\n');
fprintf('RESULTS:\n');
fprintf('SNR Improvement: %.2f dB\n', improvement_SNR);
fprintf('Coverage Improvement: %.1f%%\n', improvement_coverage);
fprintf('========================================\n\n');

%% Generate Figures
fprintf('Generating figures...\n');

% Figure 1: Network Topology
figure('Name', 'Network Topology', 'Position', [100, 100, 800, 600]);
hold on; grid on;
plot(config.gNB.position(1), config.gNB.position(2), '^r', ...
     'MarkerSize', 20, 'MarkerFaceColor', 'r', 'LineWidth', 2);
scatter(ue_x, ue_y, 150, 'bo', 'filled', 'LineWidth', 1.5);
plot(uav_x, uav_y, '--m', 'LineWidth', 2.5);
plot(uav_x(1), uav_y(1), 'pm', 'MarkerSize', 15, 'MarkerFaceColor', 'm', 'LineWidth', 2);
xlabel('X Position (m)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Y Position (m)', 'FontSize', 12, 'FontWeight', 'bold');
title('Network Topology: UAV-Assisted 5G System', 'FontSize', 14, 'FontWeight', 'bold');
legend('Base Station', 'Users', 'UAV Path', 'UAV Start', 'Location', 'best', 'FontSize', 11);
axis equal;
grid on;
set(gca, 'FontSize', 11);

% Figure 2: SNR Comparison
figure('Name', 'SNR Comparison', 'Position', [150, 150, 1000, 500]);
hold on; grid on;
plot(time, baseline_avg_SNR, '-b', 'LineWidth', 3);
plot(time, proposed_avg_SNR, '-r', 'LineWidth', 3);
yline(config.metrics.SNR_threshold, '--k', 'LineWidth', 2);
xlabel('Time (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Average SNR (dB)', 'FontSize', 12, 'FontWeight', 'bold');
title('SNR Comparison: Baseline vs UAV-Assisted', 'FontSize', 14, 'FontWeight', 'bold');
legend('Baseline (No UAV)', 'Proposed (UAV Relay)', 'SNR Threshold', ...
       'Location', 'best', 'FontSize', 11);
grid on;
set(gca, 'FontSize', 11);
ylim([min([baseline_avg_SNR, proposed_avg_SNR])-5, max([baseline_avg_SNR, proposed_avg_SNR])+5]);

% Figure 3: Coverage Comparison with filled areas
figure('Name', 'Coverage Comparison', 'Position', [200, 200, 1000, 500]);
hold on; grid on;

% Fill areas
fill([time, fliplr(time)], [proposed_coverage, zeros(size(proposed_coverage))], ...
     [1, 0.7, 0.7], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
fill([time, fliplr(time)], [baseline_coverage, zeros(size(baseline_coverage))], ...
     [0.7, 0.7, 1], 'EdgeColor', 'none', 'FaceAlpha', 0.4);

% Plot lines
plot(time, baseline_coverage, '-b', 'LineWidth', 4);
plot(time, proposed_coverage, '-r', 'LineWidth', 4);

xlabel('Time (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Coverage (%)', 'FontSize', 12, 'FontWeight', 'bold');
title('Coverage Comparison: Baseline vs UAV-Assisted', 'FontSize', 14, 'FontWeight', 'bold');
legend('Proposed Fill', 'Baseline Fill', 'Baseline (No UAV)', 'Proposed (UAV Relay)', ...
       'Location', 'best', 'FontSize', 11);
ylim([0, 100]);
grid on;
set(gca, 'FontSize', 11);

% Add text annotations
text(5, 90, sprintf('Proposed Avg: %.1f%%', mean(proposed_coverage)), ...
     'FontSize', 12, 'Color', 'r', 'FontWeight', 'bold', 'BackgroundColor', 'w');
text(5, 10, sprintf('Baseline Avg: %.1f%%', mean(baseline_coverage)), ...
     'FontSize', 12, 'Color', 'b', 'FontWeight', 'bold', 'BackgroundColor', 'w');

% Figure 4: Performance Improvement Bar Chart
figure('Name', 'Performance Improvement', 'Position', [250, 250, 800, 600]);
categories = {'Average SNR (dB)', 'Coverage (%)'};
baseline_vals = [mean(baseline_avg_SNR), mean(baseline_coverage)];
proposed_vals = [mean(proposed_avg_SNR), mean(proposed_coverage)];

x = 1:length(categories);
width = 0.35;
bar(x - width/2, baseline_vals, width, 'FaceColor', [0.2, 0.4, 0.8], 'EdgeColor', 'k', 'LineWidth', 1.5);
hold on;
bar(x + width/2, proposed_vals, width, 'FaceColor', [0.8, 0.2, 0.2], 'EdgeColor', 'k', 'LineWidth', 1.5);

set(gca, 'XTick', x, 'XTickLabel', categories, 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Value', 'FontSize', 12, 'FontWeight', 'bold');
title('Performance Comparison: Baseline vs UAV-Assisted', 'FontSize', 14, 'FontWeight', 'bold');
legend('Baseline (No UAV)', 'Proposed (UAV Relay)', 'Location', 'northwest', 'FontSize', 11);
grid on;
set(gca, 'FontSize', 11);

% Add value labels on bars
for i = 1:length(categories)
    text(x(i) - width/2, baseline_vals(i) + 2, sprintf('%.1f', baseline_vals(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');
    text(x(i) + width/2, proposed_vals(i) + 2, sprintf('%.1f', proposed_vals(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');
end

fprintf('All figures generated successfully!\n');
fprintf('Simulation complete.\n');

%% Helper Functions
function PL_dB = calculate_terrestrial_pathloss(distance, config)
    c = 3e8;
    f_MHz = config.carrierFrequency / 1e6;
    hb = config.gNB.antennaHeight;
    hm = config.UE.antennaHeight;
    d_km = distance / 1000;
    
    % Okumura-Hata model for rural areas
    a_hm = (1.1*log10(f_MHz) - 0.7)*hm - (1.56*log10(f_MHz) - 0.8);
    PL_dB = 69.55 + 26.16*log10(f_MHz) - 13.82*log10(hb) - a_hm + ...
            (44.9 - 6.55*log10(hb))*log10(d_km);
    
    % Add shadow margin
    shadow_margin = 8;
    PL_dB = PL_dB + shadow_margin;
    
    % Ensure minimum path loss (free space)
    FSPL_dB = 20*log10(distance) + 20*log10(config.carrierFrequency) + 20*log10(4*pi/c);
    PL_dB = max(PL_dB, FSPL_dB);
end

function PL_dB = calculate_A2G_pathloss(distance, config)
    c = 3e8;
    
    % Free space path loss
    FSPL_dB = 20*log10(distance) + 20*log10(config.carrierFrequency) + 20*log10(4*pi/c);
    
    % Additional loss for A2G channel
    if strcmp(config.channel.environmentType, 'rural')
        eta_LoS = 1;
        eta_NLoS = 20;
    else
        eta_LoS = 1;
        eta_NLoS = 20;
    end
    
    if rand() < config.channel.LoS_probability
        additional_loss = eta_LoS;
    else
        additional_loss = eta_NLoS;
    end
    
    PL_dB = FSPL_dB + additional_loss;
end

function SNR_dB = calculate_SNR(txPower_dBm, txGain_dBi, rxGain_dBi, pathLoss_dB, noiseFigure_dB, bandwidth_Hz)
    k_B = 1.38e-23;
    T = 290;
    
    % Received power
    P_rx_dBm = txPower_dBm + txGain_dBi + rxGain_dBi - pathLoss_dB;
    
    % Noise power
    N_W = k_B * T * bandwidth_Hz;
    N_dBm = 10*log10(N_W * 1000);
    N_total_dBm = N_dBm + noiseFigure_dB;
    
    % SNR
    SNR_dB = P_rx_dBm - N_total_dBm;
end
